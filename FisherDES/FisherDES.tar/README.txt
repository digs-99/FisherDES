#The file takes four command line arguments, an input data file, an input key file, an output file, and a mode value 0- for encrypt and 1 for decrypt
# for example when in the directory that this code exists use the command line argument below to execute the code
# python3 input.txt keys.txt output.txt 0/1
# the code will overwrite to the desination of the output file.
# the main code simply takes the input values, formats them, and then calls helperDES functions
# the code presumes you are running python3

